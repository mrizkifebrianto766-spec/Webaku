document.getElementById("lanjutDonate").addEventListener("click", function () {

  const amount = parseInt(document.getElementById("donateAmount").value);

  const metode = document.getElementById("paymentMethod").value;

  if (!amount || amount < 1000 || amount > 1000000) {

    alert("Jumlah harus antara 1.000 - 1.000.000");

    return;

  }

  if (!metode) {

    alert("Pilih metode pembayaran terlebih dahulu!");

    return;

  }

  alert("Terima kasih donate-nya 😘");

});